# Secure Web Application with Flask

This project demonstrates a secure web application built with Flask, implementing key cybersecurity practices.

## 🔧 Tools Used
- Python (Flask)
- JWT (PyJWT)
- Bcrypt for password hashing
- SQLite (safe from SQL Injection)

## 🔐 Features
- User registration & login with hashed passwords
- JWT-based authentication
- SQL Injection protection
- Secure route access

## 🚀 How to Run
1. Install dependencies:
```bash
pip install -r requirements.txt
```
2. Run the application:
```bash
python app.py
```

## ✅ Skills Gained
- Web security basics (OWASP Top 10)
- Authentication & session handling
- Input validation & hashing

## 📁 Routes
- `/register`
- `/login`
- `/dashboard` (JWT protected)
